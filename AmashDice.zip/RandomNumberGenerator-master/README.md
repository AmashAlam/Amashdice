## Random Number Generator

### This was a challenge on Codementor

[Click here to see the live Demo](https://random-dice-roller.herokuapp.com/index.php)
