function reloadPage(){
    window.location.href = window.location.href;
}